import React, { useEffect, useRef } from "react";

interface AdsterraBannerProps {
  className?: string;
  label?: boolean;
}

export const AdsterraBanner: React.FC<AdsterraBannerProps> = ({
  className = "",
  label = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const scriptInjectedRef = useRef(false);

  useEffect(() => {
    if (scriptInjectedRef.current || !containerRef.current) return;

    try {
      const script = document.createElement("script");
      script.type = "text/javascript";
      script.async = true;
      script.setAttribute("data-cfasync", "false");
      script.src = "https://pl31189294.profitableratecpmnetwork.com/301016721a34ff6139e245e9ed74ebf2/invoke.js";

      containerRef.current.appendChild(script);
      scriptInjectedRef.current = true;
    } catch (err) {
      console.warn("Adsterra banner error:", err);
    }
  }, []);

  return (
    <div
      className={`relative w-full overflow-hidden rounded-xl bg-[#181818]/70 border border-white/5 p-2 text-center transition-all ${className}`}
    >
      {label && (
        <div className="flex items-center justify-between px-2 pb-1 text-[10px] text-zinc-500 font-medium tracking-wider uppercase">
          <span>Partenaire Sponsorisé</span>
          <span className="text-[9px] text-zinc-500">Adsterra</span>
        </div>
      )}
      <div
        ref={containerRef}
        id="container-301016721a34ff6139e245e9ed74ebf2"
        className="w-full flex items-center justify-center min-h-[60px] overflow-hidden"
      />
    </div>
  );
};
