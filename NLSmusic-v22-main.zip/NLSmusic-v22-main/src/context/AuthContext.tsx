import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { User, AuthResponse } from "../types";
import { onAuthStateChanged } from "firebase/auth";
import {
  auth,
  signInWithGoogle,
  signInWithIdentifier,
  registerWithUsername,
  isUsernameAvailable,
  logoutFirebase,
  testFirestoreConnection,
  mapFirebaseUser,
} from "../services/firebase";
import {
  getCurrentUser,
  loginUser,
  registerUser,
  checkServerUsername,
  logoutUser,
  updateUserProfile,
  getStoredAuthToken,
} from "../services/api";

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAuthModalOpen: boolean;
  authModalInitialTab: "login" | "register";
  openAuthModal: (tab?: "login" | "register") => void;
  closeAuthModal: () => void;
  login: (identifier: string, pass: string) => Promise<AuthResponse>;
  loginWithGoogle: () => Promise<AuthResponse>;
  register: (username: string, pass: string, genre?: string, email?: string) => Promise<AuthResponse>;
  checkUsername: (username: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateProfile: (data: { name?: string; favoriteGenre?: string; avatar?: string }) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const CACHED_USER_KEY = "nlsmusic_cached_user";

function getStoredCachedUser(): User | null {
  try {
    const raw = localStorage.getItem(CACHED_USER_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function setStoredCachedUser(user: User | null): void {
  try {
    if (user) {
      localStorage.setItem(CACHED_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CACHED_USER_KEY);
    }
  } catch {}
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => getStoredCachedUser());
  const [isLoading, setIsLoading] = useState<boolean>(() => !getStoredCachedUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalInitialTab, setAuthModalInitialTab] = useState<"login" | "register">("login");

  // Keep localStorage user cache in sync
  const updateActiveUser = useCallback((newUser: User | null) => {
    setUser(newUser);
    setStoredCachedUser(newUser);
  }, []);

  // Initialize Firebase Auth listener & Test connection
  useEffect(() => {
    let isMounted = true;

    // Test Firestore connectivity in background
    testFirestoreConnection().catch(() => {});

    // Listen for Firebase Auth state changes
    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (!isMounted) return;
      if (fbUser) {
        const mapped = mapFirebaseUser(fbUser);
        updateActiveUser(mapped);
        setIsLoading(false);
      } else {
        // Fallback: check stored local server token
        const token = getStoredAuthToken();
        if (token) {
          getCurrentUser()
            .then((u) => {
              if (isMounted) {
                if (u) {
                  updateActiveUser(u);
                } else {
                  updateActiveUser(null);
                }
                setIsLoading(false);
              }
            })
            .catch(() => {
              if (isMounted) {
                // If offline but cached user exists, keep cached user
                const cached = getStoredCachedUser();
                if (!cached) {
                  updateActiveUser(null);
                }
                setIsLoading(false);
              }
            });
        } else {
          // If no token and no Firebase user, clear user
          updateActiveUser(null);
          setIsLoading(false);
        }
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [updateActiveUser]);

  const openAuthModal = useCallback((tab: "login" | "register" = "login") => {
    setAuthModalInitialTab(tab);
    setIsAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setIsAuthModalOpen(false);
  }, []);

  const loginWithGoogleHandler = useCallback(async (): Promise<AuthResponse> => {
    try {
      const u = await signInWithGoogle();
      if (!u) {
        // User closed or cancelled the popup without error
        return { success: false };
      }
      updateActiveUser(u);
      setIsAuthModalOpen(false);
      return { success: true, user: u };
    } catch (err: any) {
      return { success: false, error: err?.message || "Erreur de connexion Google" };
    }
  }, [updateActiveUser]);

  const login = useCallback(async (identifier: string, pass: string): Promise<AuthResponse> => {
    try {
      // 1. Try Firebase Auth with identifier (username or email)
      const u = await signInWithIdentifier(identifier, pass);
      updateActiveUser(u);
      setIsAuthModalOpen(false);
      return { success: true, user: u };
    } catch (err: any) {
      // 2. Seamlessly authenticate with backend server
      const res = await loginUser(identifier, pass);
      if (res.success && res.user) {
        updateActiveUser(res.user);
        setIsAuthModalOpen(false);
        return res;
      }
      const isOpNotAllowed =
        err?.code === "auth/operation-not-allowed" ||
        err?.message?.includes("operation-not-allowed");
      const errorMsg =
        res.error ||
        (isOpNotAllowed ? "Nom d'utilisateur ou mot de passe incorrect." : err?.message) ||
        "Identifiants invalides.";
      return { success: false, error: errorMsg };
    }
  }, [updateActiveUser]);

  const checkUsername = useCallback(async (username: string): Promise<boolean> => {
    const isFbAvail = await isUsernameAvailable(username);
    if (!isFbAvail) return false;
    const isSrvAvail = await checkServerUsername(username);
    return isSrvAvail;
  }, []);

  const register = useCallback(
    async (
      username: string,
      pass: string,
      genre?: string,
      email?: string
    ): Promise<AuthResponse> => {
      try {
        // 1. Try Firebase Auth with unique username
        const u = await registerWithUsername(username, pass, genre, email);
        updateActiveUser(u);
        setIsAuthModalOpen(false);
        return { success: true, user: u };
      } catch (err: any) {
        // 2. Seamless fallback to server register
        const res = await registerUser(username, pass, genre, email);
        if (res.success && res.user) {
          updateActiveUser(res.user);
          setIsAuthModalOpen(false);
          return res;
        }
        const isOpNotAllowed =
          err?.code === "auth/operation-not-allowed" ||
          err?.message?.includes("operation-not-allowed");
        const errorMsg =
          res.error ||
          (isOpNotAllowed ? "Impossible de créer le compte. Veuillez réessayer." : err?.message) ||
          "Échec de l'inscription.";
        return { success: false, error: errorMsg };
      }
    },
    [updateActiveUser]
  );

  const logout = useCallback(async () => {
    try {
      await logoutFirebase();
    } catch {}
    try {
      await logoutUser();
    } catch {}
    updateActiveUser(null);
  }, [updateActiveUser]);

  const updateProfile = useCallback(
    async (data: { name?: string; favoriteGenre?: string; avatar?: string }): Promise<boolean> => {
      const updated = await updateUserProfile(data);
      if (updated) {
        updateActiveUser(updated);
        return true;
      }
      if (user) {
        const merged = { ...user, ...data };
        updateActiveUser(merged);
        return true;
      }
      return false;
    },
    [user, updateActiveUser]
  );

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        isAuthModalOpen,
        authModalInitialTab,
        openAuthModal,
        closeAuthModal,
        login,
        loginWithGoogle: loginWithGoogleHandler,
        register,
        checkUsername,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
